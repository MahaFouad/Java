package Test_Cases;

import APIs.Details;

public class Validate_Details_API_Res {

	public static void main(String[] args) 
	{
		Details details_Obj = new Details();
		details_Obj.get_Details(false);
		if (details_Obj.verify_Prom_Desc("Gallery","2x larger image"))
		{
			System.out.println("The Promotions element with Name = \"Gallery\" has a Description that "
					+ "contains the text \"2x larger image\"" );
		}
		else
		{
			System.err.println("The Promotions element with Name = \"Gallery\" has NOT a Description that "
					+ "contains the text \"2x larger image\"" );
		}
		
		String[] param_Names={"Name","CanRelist"};
		String[] param_Values={"Carbon credits","true"};
		String[][] results=details_Obj.verify_Param_Values(param_Names,param_Values);
		for (int c=0; c<results.length; c++)
		{
			if (results[c][1].equals("true"))
			{
				System.out.println(param_Names[c]+"="+param_Values[c]+" successfully");
			}
			else
			{
				System.err.println("Expected: "+param_Names[c]+"="+param_Values[c]+
						"\r\nActual: "+param_Names[c]+"="+results[c][1]);
			}
		}
		
	}

}
