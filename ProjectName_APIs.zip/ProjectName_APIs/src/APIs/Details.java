package APIs;

import java.io.IOException;
import java.util.Iterator;
import Configuration.Server_Connection;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

public class Details extends Server_Connection 
{
	org.json.simple.parser.JSONParser parser;
	Object obj;
	org.json.simple.JSONObject json_Obj;
	
	public Details()
	{
		parser = new org.json.simple.parser.JSONParser();
	}
	
	public void get_Details(boolean catalogue)
	{
		try 
		{
			get("/v1/Categories/6327/Details.json?catalogue="+catalogue);
			try 
			{
				obj = parser.parse(result);
				json_Obj = (JSONObject) obj;
			} 
			catch (ParseException e) 
			{
				e.printStackTrace();
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}	
	}
	
	public String[][] verify_Param_Values(String param[], String value[])
	{
		String[][] match_res=new String[param.length][2];
		for (int c=0; c<param.length; c++)
		{
			if ((result.contains("\""+param[c]+"\":\""+value[c]+"\"")) || (result.contains("\""+param[c]+"\":"+value[c])))
			{
				match_res[c][0]="true";
				match_res[c][1]="true";
			}
			else
			{
				match_res[c][0]="false";
				match_res[c][1]=json_Obj.get(param[c]).toString();
			}
		}
		return match_res;
	}
	
	public boolean verify_Prom_Desc(String name_Value, String description)
	{
		org.json.simple.JSONArray promotions = (org.json.simple.JSONArray) json_Obj.get("Promotions");						
		Iterator<org.json.simple.JSONObject> iterator = promotions.iterator();
		while(iterator.hasNext())
		{
			org.json.simple.JSONObject current = iterator.next();
			if(current.get("Name").equals(name_Value) && current.get("Description").toString().contains(description))
			{
			     return true;
			}
		}
		return false;
	}
}