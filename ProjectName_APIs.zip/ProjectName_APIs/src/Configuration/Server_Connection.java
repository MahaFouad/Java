package Configuration;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Properties;

public class Server_Connection 
{
	public Properties config;
	public String Conf_File_Location;
	public FileInputStream server_Conf_File; 
	public String server_Name;
	public String protocol;
	public String uri;
	public URL url;
	public HttpURLConnection connection;
	public static String result;
	
	public Server_Connection()
	{
		config = new Properties();
		Conf_File_Location=System.getProperty("user.dir") + "\\src\\Configuration\\Server";
		try 
		{
			server_Conf_File = new FileInputStream(Conf_File_Location);
		} 
		catch (FileNotFoundException e1) 
		{
			System.err.println("Execution stopped, Server configuration file not exist.\r\nFile location: "
						+Conf_File_Location);
			System.exit(0);
		}
		try 
		{
			config.load(server_Conf_File);
		} 
		catch (IOException e1) 
		{
			System.err.println("Execution stopped,"+e1.getStackTrace());
			System.exit(0);
		}	
		uri = config.getProperty("protocol")+"://"+config.getProperty("server_Name");
		result="";
	}
	
	public void get(String path) throws IOException
	{
		InputStreamReader in;
		BufferedReader br;
		try 
		{
			url = new URL(uri+path);
		} 
		catch (MalformedURLException e) 
		{
			System.err.println("Invalid URL: "+uri+path);
			
		}
		connection = (HttpURLConnection)url.openConnection();
		connection.setConnectTimeout(5000);
		connection.setReadTimeout(5000);
		try 
		{
			connection.setRequestMethod("GET");
		} 
		catch (ProtocolException e) 
		{
			System.err.println("Get method is not allowed for: "+uri+path);
			e.printStackTrace();
		}
		
		in = new InputStreamReader(connection.getInputStream());
        br = new BufferedReader(in);
        String output;
        while ((output = br.readLine()) != null) {
        	result=result+output;
        }
	}
}
